<?php
/* Template Name: Landing Demo */
get_header();
echo '<div class="gip-landing">';
echo do_shortcode('[gip_site_list]');
echo '</div>';
get_footer();
#!/bin/bash
echo "Ativando plugins para o Microsite GIP Demo..."
wp plugin activate elementor
wp plugin activate jet-engine
wp plugin activate wp-mail-smtp-pro
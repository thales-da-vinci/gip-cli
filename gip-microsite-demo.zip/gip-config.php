<?php
define('GIP_SYSTEM', __DIR__ . '/gip-system');
define('WP_CONTENT_DIR', GIP_SYSTEM);
define('WP_PLUGIN_DIR', GIP_SYSTEM . '/modules');
define('UPLOADS', 'gip-system/media');
define('WP_CONTENT_URL', 'https://demo-cliente.com/gip-system');
define('WP_PLUGIN_URL', 'https://demo-cliente.com/gip-system/modules');
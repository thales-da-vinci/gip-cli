## v1.0.0
- Estrutura GIP completa ativada
- Tema gip-base
- Plugins ativos: Elementor, SMTP, JetEngine
- Painel JetEngine funcional com sites de exemplo
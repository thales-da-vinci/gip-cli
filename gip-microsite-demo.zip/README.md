# 🧪 Microsite GIP - Demo

Este projeto é um exemplo completo de microsite com estrutura GIP ativada e integração com JetEngine.

## ✅ O que está incluído

- Tema: `gip-base` (Hello Elementor adaptado)
- Plugins: Elementor, JetEngine, SMTP Pro
- Painel: JetEngine + [gip_site_list]
- Shortcode ativo na landing

## Como usar

1. Suba em seu servidor
2. Ative o tema e plugins com `plugin-installer.sh`
3. Importe CPTs e relações JetEngine
4. Acesse /pages/landing.php como página inicial